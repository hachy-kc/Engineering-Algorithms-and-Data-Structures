1.

Requirement 1: Has been completed and works

Requirement 2: Has been completed and works

2.

To check for a stand-alone tag I can add an if statement where it will check to see if there is a "/" after the characters or if it is an alphabet. If there is a "/" then it is a stand-alone tag and the program will print as VALID.